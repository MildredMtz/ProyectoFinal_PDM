package com.example.tarea2menus;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class CambioDatos  extends BaseNavBar {


    private  boolean variable =false;
    List<String> lista = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        //setContentView(R.layout.activity_cambio_datos);
        getLayoutInflater().inflate(R.layout.activity_cambio_datos, findViewById(R.id.container));


        // Crear una instancia del helper
        //Importante tener todas las instancias que ocupemos la misma version.
        UsuariosSQLiteHelper usdbh = new UsuariosSQLiteHelper(this, "DBUsuarios", null, 12);

        // Abrir la base de datos en modo escritura
        SQLiteDatabase db = usdbh.getWritableDatabase();




        //Para guardar el nombre de usuario Actual


        SharedPreferences sharedPreferences = getSharedPreferences("UsuarioActual", MODE_PRIVATE);
        String nombre = sharedPreferences.getString("usuario", "Desconocido");



        //Obteniendo informacion de la base de datos



        String query = "SELECT Usuarios.nombre,Usuarios.email,Usuarios.codigo,Datos.genero ,Datos.meta ,Datos.comentario  " +
                "FROM Usuarios " +
                "INNER JOIN Datos ON Usuarios.nombre = Datos.nombre " +
                "WHERE Usuarios.nombre = ?";

        String[] args = {nombre}; // Argumentos para el WHERE
        //Nota importante se la funcion de los argumentos es evitar la inyección de SQL

        @SuppressLint("Recycle")
        Cursor cursor = db.rawQuery(query, args);

        String nombre1 = "";
        String email1 = "";
        String genero1 = "";
        String meta1 = "";
        String comentario1 = "";
        String codigo1= "";


        // Procesar los resultados
        if (cursor.moveToFirst()) {
            do {
                nombre1 = cursor.getString(0); // Primera columna: Usuarios.nombre
                email1 = cursor.getString(1); // Segunda columna: Pedidos.producto
                codigo1 = cursor.getString(2);
                genero1 = cursor.getString(3); // Tercera columna: Pedidos.producto
                meta1 = cursor.getString(4); // Cuarta columna: Pedidos.producto
                comentario1 = cursor.getString(5); // Quinta columna: Pedidos.producto


                Log.d("Resultado", "Nombre: " + nombre1 + ", email: " + email1 + ", genero: " + genero1
                        + ", meta: " + meta1+ ", comentario: " + comentario1);

            } while (cursor.moveToNext());
        }


        String query2 = "SELECT Usuarios.nombre,Dias.dia  " +
                "FROM Usuarios " +
                "INNER JOIN Dias ON Usuarios.nombre = Dias.nombre " +
                "WHERE Usuarios.nombre = ?";

        String[] args2 = {nombre}; // Argumentos para el WHERE
        //Nota importante se la funcion de los argumentos es evitar la inyección de SQL

        Cursor cursor2 = db.rawQuery(query2, args2);

        // Procesar los resultados
        if (cursor2.moveToFirst()) {
            do {

                String dias1= cursor2.getString(1); // Segunda columna: Pedidos.producto

                Log.i("ddd", "onCreate: "+dias1);
                lista.add(dias1); // Agrega un valor en cada iteración

            } while (cursor2.moveToNext());
        }

        cursor2.close();




        // Cerrar cursor y base de datos
        cursor.close();



        final String[] datos =
                new String[]{"Estar mas delgad@ ", "Ser mas fuerte ", "Salud", "Evitar estres", "Estetica", "Aburrimiento", "Otro"};
        ArrayAdapter<String> adaptador =
                new ArrayAdapter<String>(this,
                        R.layout.spinner_item, datos);


        // Se utilza para mostrar una lista desplegable
        Spinner cmbOpciones = (Spinner) findViewById(R.id.CmbOpciones);
        adaptador.setDropDownViewResource(
                R.layout.spinner_item);
        cmbOpciones.setAdapter(adaptador);





















        ///ACTUALIZACON DE LOS XML CON LOS DATOS DE LA BASE DE DATOS
        /// Asignar info Para el spinner

        int valorSpinner =0;
        switch (meta1) {
            case "Estar más delgad@":
                System.out.println("Has elegido: Estar más delgad@.");
                valorSpinner=0;
                cmbOpciones.setSelection(valorSpinner);
                break;

            case "Ser más fuerte":
                System.out.println("Has elegido: Ser más fuerte.");
                valorSpinner=1;
                cmbOpciones.setSelection(valorSpinner);
                break;

            case "Salud":
                System.out.println("Has elegido: Salud.");
                valorSpinner=2;
                cmbOpciones.setSelection(valorSpinner);
                break;

            case "Evitar estrés":
                System.out.println("Has elegido: Evitar estrés.");
                valorSpinner=3;
                cmbOpciones.setSelection(valorSpinner);
                break;

            case "Estética":
                System.out.println("Has elegido: Estética.");
                valorSpinner=4;
                cmbOpciones.setSelection(valorSpinner);
                break;

            case "Aburrimiento":
                System.out.println("Has elegido: Aburrimiento.");
                valorSpinner=5;
                cmbOpciones.setSelection(valorSpinner);
                break;

            case "Otro":
                System.out.println("Has elegido: Otro.");
                valorSpinner=6;
                cmbOpciones.setSelection(valorSpinner);
                break;

        }

        //
        cmbOpciones.setSelection(valorSpinner);


        // Radio Boton del genero
        RadioGroup radioGroup = findViewById(R.id.gruporb);

        //Selecciona el genero guardado
        switch (genero1) {
            case "Hombre":
                System.out.println("Has elegido: Hombre.");
                radioGroup.check(R.id.radio1);
                break;

            case "Mujer":
                System.out.println("Has elegido: Mujer.");
                radioGroup.check(R.id.radio2);
                break;

            case "Otro":
                System.out.println("Has elegido: Otro.");
                radioGroup.check(R.id.radio3);
                break;

        }


        //Para mostrar los dias guardados

        LinearLayout layout = findViewById(R.id.grupoCheckBoxs); // Contenedor de los CheckBox
        List<String> selectedOptions = new ArrayList<>();
        for (int i = 0; i < layout.getChildCount(); i++) {
            View child = layout.getChildAt(i);
            if (child instanceof CheckBox) {
                CheckBox checkBox = (CheckBox) child;
                // para verificar si esta en la lista de los dias seleccionados
                if (lista.stream().anyMatch(s -> s.equalsIgnoreCase((String) checkBox.getText()))){
                    checkBox.setChecked(true);
                }

            }
        }


        //Para mostrar la información del editText guardado

        EditText editText = findViewById(R.id.TxtUsuario);
        editText.setText(comentario1);





        final Button btnHola = (Button) findViewById(R.id.BtnEnviar);

        //Implementamos el evento "click" del botón
        //Nota : poner el boton , antes del ViewCompart(Lo que ya estaba )
        btnHola.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                ///// ACTUALIZAREMOS LA INFORMACIoN




                // Obtener el ID del RadioButton seleccionado
                int selectedRadioButtonId = radioGroup.getCheckedRadioButtonId();
                String selectedText = "";
                // Verificar si hay una opción seleccionada
                if (selectedRadioButtonId != -1) {
                    // Obtener el RadioButton seleccionado
                    RadioButton selectedRadioButton = findViewById(selectedRadioButtonId);

                    // Obtener el texto del RadioButton seleccionado
                    selectedText = selectedRadioButton.getText().toString();


                }


                /////// EditText del comentario Personal
                // Obtener la referencia al EditText
                EditText  editText = findViewById(R.id.TxtUsuario);

                // Obtener el texto ingresado (como Editable)
                String inputText = editText.getText().toString();


                // Del spinner (lista desplegable)
                // Obtener la referencia al Spinner
                Spinner spinner = findViewById(R.id.CmbOpciones);

                // Obtener el valor seleccionado
                String selectedItem = spinner.getSelectedItem().toString();

                // Mostrar el valor seleccionado en un Toast o usarlo de otra forma
                //Toast.makeText(this, "Opción seleccionada: " + selectedItem, Toast.LENGTH_SHORT).show();


                ContentValues values = new ContentValues();

                try {

                    //values.put("nombre", nombre);
                    values.put("genero", selectedText);
                    values.put("meta", selectedItem);
                    values.put("comentario", inputText);


                    int x=db.update("Datos",values,null,null);  // Usa insertOrThrow para lanzar una excepción en caso de error
                    System.out.println("el numero de filas para datos fueron " + x);


                    // Inserta o lanza error , depende si los valores ingresados son correctos

                } catch (SQLiteConstraintException e) {
                    Log.e("SQLite", e.toString() + values);
                }

                //no es necesario borrar amenos que vaya a reocupar el objeto
                values.clear();  // Borra todos los valores de ContentValues.


                ////Para obtener la información de los checkbox ,Utiliza un for , para recorrer todos
                //los hijos(checkbox) del layout
                LinearLayout layout = findViewById(R.id.grupoCheckBoxs); // Contenedor de los CheckBox
                List<String> selectedOptions = new ArrayList<>();

                String selection = "nombre = ?";
                String[] selectionArgs = { nombre };
                db.delete("Dias", selection, selectionArgs);

                for (int i = 0; i < layout.getChildCount(); i++) {
                    View child = layout.getChildAt(i);
                    if (child instanceof CheckBox) {
                        CheckBox checkBox = (CheckBox) child;
                        if (checkBox.isChecked()) {
                            //selectedOptions.add(checkBox.getText().toString());
                            //aqui seria agregarlo a la base de datos
                            values.put("nombre", nombre);
                            values.put("dia", checkBox.getText().toString());

                            try {

                                // Inserta o lanza error , depende si los valores ingresados son correctos
                                db.insertOrThrow("Dias",null, values);  // Usa insertOrThrow para lanzar una excepción en caso de error

                                printContentValues(values);
                                values.clear();  // Borra todos los valores de ContentValues.

                            } catch (SQLiteConstraintException e) {
                                Log.e("SQLite", e.toString() + values + "hay un error grabe ");
                                values.clear();  // Borra todos los valores de ContentValues.

                            }


                        }
                    }
                }


                db.close();

                ///////////////////////

                //Creamos el Intent
                Intent intent = new Intent(CambioDatos.this, ExercisesGymActivity.class);

                startActivity(intent);
                finish();
            }

        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });



    }

    //se sobreescribe este metodo del ciclo de vida
    /*protected void onResume() {
        super.onResume();

        // Verifica alguna condición
        // boolean condition = checkSomeCondition();

        if (variable) {
            // Si la condición se cumple, lanza otra actividad
            Intent intent = new Intent(this, ExercisesGymActivity.class);
            startActivity(intent);
            finish();  // Opcional: Termina la actividad actual si ya no la necesitas
            // si se lo quito ya no me deja salir de la app , porque nunca termina
        }
    }

*/


    public void printContentValues(ContentValues contentValues) {
        // Itera sobre las claves y valores del ContentValues
        for (String key : contentValues.keySet()) {
            // Obtiene el valor asociado a la clave
            Object value = contentValues.get(key);
            // Imprime la clave y el valor
            System.out.println("Clave: " + key + " - Valor: " + value);
            Log.e("SQLite en valores", key + value);
        }
    }

}