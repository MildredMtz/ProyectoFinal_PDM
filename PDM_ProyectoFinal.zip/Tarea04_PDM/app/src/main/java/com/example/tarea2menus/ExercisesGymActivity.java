package com.example.tarea2menus;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ExercisesGymActivity extends BaseNavBar {

    // Declaración de las vistas
    private TextView headerText;
    private ImageView exerciseImage1, exerciseImage2, exerciseImage3, exerciseImage4, exerciseImage5;
    private TextView exerciseName1, exerciseName2, exerciseName3, exerciseName4, exerciseName5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_exercises_gym);
        getLayoutInflater().inflate(R.layout.activity_exercises_gym, findViewById(R.id.container));


        // Inicialización de las vistas
        headerText = findViewById(R.id.header_text);

        // CardView 1
        exerciseImage1 = findViewById(R.id.exercise_image1);
        exerciseName1 = findViewById(R.id.exercise_name1);

        // Agregar clic para navegar
        exerciseImage1.setOnClickListener(view -> navigateToList(exerciseName1.getText().toString()));
        exerciseName1.setOnClickListener(view -> navigateToList(exerciseName1.getText().toString()));

        // CardView 2
        exerciseImage2 = findViewById(R.id.exercise_image2);
        exerciseName2 = findViewById(R.id.exercise_name2);

        // Agregar clic para navegar
        exerciseImage2.setOnClickListener(view -> navigateToList(exerciseName2.getText().toString()));
        exerciseName2.setOnClickListener(view -> navigateToList(exerciseName2.getText().toString()));

        // CardView 3
        exerciseImage3 = findViewById(R.id.exercise_image3);
        exerciseName3 = findViewById(R.id.exercise_name3);

        // Agregar clic para navegar
        exerciseImage3.setOnClickListener(view -> navigateToList(exerciseName3.getText().toString()));
        exerciseName3.setOnClickListener(view -> navigateToList(exerciseName3.getText().toString()));

        // CardView 4
        exerciseImage4 = findViewById(R.id.exercise_image4);
        exerciseName4 = findViewById(R.id.exercise_name4);

        // Agregar clic para navegar
        exerciseImage4.setOnClickListener(view -> navigateToList(exerciseName4.getText().toString()));
        exerciseName4.setOnClickListener(view -> navigateToList(exerciseName4.getText().toString()));

        // CardView 5
        exerciseImage5 = findViewById(R.id.exercise_image5);
        exerciseName5 = findViewById(R.id.exercise_name5);

        // Agregar clic para navegar
        exerciseImage5.setOnClickListener(view -> navigateToList(exerciseName5.getText().toString()));
        exerciseName5.setOnClickListener(view -> navigateToList(exerciseName5.getText().toString()));

    }

    private void navigateToList(String exerciseName) {
        Intent intent = new Intent(this, ExerciseListActivity.class);
        intent.putExtra("exercise_name", exerciseName);

        String[] exercises;

        if (exerciseName.equals("Pecho y Abdomen")) {
            exercises = new String[]{
                    "Press de banca 4x12",
                    "Elevación de piernas en máquina 4x12",
                    "Plancha isométrica 1 min",
                    "Press con macuerna 4x20",
                    "Jalón a pecho 4x15",
                    "Estiramiento de espalda en arco 4x20",
                    "Cruces en polea baja 4x15",
                    "Crossover 4x12"
            };
        } else if (exerciseName.equals("Cuadriceps")) {
            exercises = new String[]{
                    "Sentadilla 4x12",
                    "Hack 4x12",
                    "Prensa 4x10",
                    "Goblet 4x20",
                    "Extensiones en máquina 4x15",
                    "Costurera 4x20",
                    "Aductores 4x15",
                    "Elevación de talon 50 seguidas"
            };
        } else if (exerciseName.equals("Glúteo y Femoral")) {
            exercises = new String[]{
                    "Femoral acostado 4x12",
                    "Femoral sentado 4x12",
                    "Sentadilla búlgara 4x15",
                    "Peso muerto 4x20",
                    "Elevaciones laterales con grilletes 4x15",
                    "Patada de glúteo con grilletes 4x20",
                    "Abductores en máquina 4x15",
                    "Hip thrust 4x12"
            };
        } else if (exerciseName.equals("Espalda y Hombro")) {
            exercises = new String[]{
                    "Remo sentado 4x12",
                    "Pull over 4x12",
                    "Jalón agarre abierto 4x10",
                    "Jalón agarre cerrado 4x20",
                    "Laterales 4x15",
                    "Frontales 4x20",
                    "Press en máquina 4x15",
                    "Press con mancuerna 4x12"
            };
        } else if (exerciseName.equals("Tríceps y Bíceps")) {
            exercises = new String[]{
                    "Extensiones de tríceps 4x12",
                    "Copa 4x12",
                    "Rompe craneos 4x15",
                    "Martillos 4x20",
                    "Extension de tríceps a una mano 4x15",
                    "Máquina de predicador 4x20",
                    "Curl con barra 4x15",
                    "Curl a una mano 4x12"
            };
        } else {
            exercises = new String[]{"No hay ejercicios disponibles"};
        }

        intent.putExtra("exercises", exercises);
        startActivity(intent);
    }

}

