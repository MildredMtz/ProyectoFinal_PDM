package com.example.tarea2menus;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Esta clase es para listar los ejercicios de casa
 */
public class ExercisesHomeActivity extends BaseNavBar{

    // Declaración de las vistas
    private TextView headerText;
    private ImageView exerciseImage1, exerciseImage2, exerciseImage3, exerciseImage4, exerciseImage5;
    private TextView exerciseName1, exerciseName2, exerciseName3, exerciseName4, exerciseName5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_exercises);
        getLayoutInflater().inflate(R.layout.activity_exercises, findViewById(R.id.container));


        // Inicialización de las vistas
        headerText = findViewById(R.id.header_text);

        // CardView 1
        exerciseImage1 = findViewById(R.id.exercise_image1);
        exerciseName1 = findViewById(R.id.exercise_name1);

        // Agregar clic para navegar
        exerciseImage1.setOnClickListener(view -> navigateToList(exerciseName1.getText().toString()));
        exerciseName1.setOnClickListener(view -> navigateToList(exerciseName1.getText().toString()));

        // CardView 2
        exerciseImage2 = findViewById(R.id.exercise_image2);
        exerciseName2 = findViewById(R.id.exercise_name2);

        // Agregar clic para navegar
        exerciseImage2.setOnClickListener(view -> navigateToList(exerciseName2.getText().toString()));
        exerciseName2.setOnClickListener(view -> navigateToList(exerciseName2.getText().toString()));

        // CardView 3
        exerciseImage3 = findViewById(R.id.exercise_image3);
        exerciseName3 = findViewById(R.id.exercise_name3);

        // Agregar clic para navegar
        exerciseImage3.setOnClickListener(view -> navigateToList(exerciseName3.getText().toString()));
        exerciseName3.setOnClickListener(view -> navigateToList(exerciseName3.getText().toString()));

        // CardView 4
        exerciseImage4 = findViewById(R.id.exercise_image4);
        exerciseName4 = findViewById(R.id.exercise_name4);

        // Agregar clic para navegar
        exerciseImage4.setOnClickListener(view -> navigateToList(exerciseName4.getText().toString()));
        exerciseName4.setOnClickListener(view -> navigateToList(exerciseName4.getText().toString()));

        // CardView 5
        exerciseImage5 = findViewById(R.id.exercise_image5);
        exerciseName5 = findViewById(R.id.exercise_name5);

        // Agregar clic para navegar
        exerciseImage5.setOnClickListener(view -> navigateToList(exerciseName5.getText().toString()));
        exerciseName5.setOnClickListener(view -> navigateToList(exerciseName5.getText().toString()));

    }

    private void navigateToList(String exerciseName) {
        Intent intent = new Intent(this, ExerciseListActivity.class);
        intent.putExtra("exercise_name", exerciseName);

        String[] exercises;

        if (exerciseName.equals("Estiramientos")) {
            exercises = new String[]{
                    "Zancada con rotación 4x12",
                    "Step back squat 4x12",
                    "Plancha isométrica 1 min",
                    "Warm up roll 4x20",
                    "Postura del gato 4x15",
                    "Estiramiento de espalda en arco 4x20",
                    "Wall climb 4x15",
                    "Estiramiento de aductores 4x12"
            };
        } else if (exerciseName.equals("Cuadriceps")) {
            exercises = new String[]{
                    "Sentadilla normal 4x12",
                    "Zancadas traseras 4x12",
                    "Sentadilla búlgara 4x10",
                    "Sentadilla sumo 4x20",
                    "Zancadas laterales 4x15",
                    "Sentadillas isométricas 4x20",
                    "Caminata de pato 4x15",
                    "Elevación de talon 50 seguidas"
            };
        } else if (exerciseName.equals("Glúteo y Femoral")) {
            exercises = new String[]{
                    "Puente 4x12",
                    "Frog pumps 4x12",
                    "Sentadilla búlgara 4x15",
                    "Peso muerto 4x20",
                    "Elevaciones laterales 4x15",
                    "Patada de glúteo con liga 4x20",
                    "Abductores con liga 4x15",
                    "Hip thrust 4x12"
            };
        } else if (exerciseName.equals("Espalda y Hombro")) {
            exercises = new String[]{
                    "Dominadas 4x12",
                    "Remo invertido 4x12",
                    "Remo con liga 4x10",
                    "Pull over con liga 4x20",
                    "Fondos 4x15",
                    "Flexiones 4x20",
                    "Laterales con liga 4x15",
                    "Frontales con liga 4x12"
            };
        } else if (exerciseName.equals("Abdomen Tríceps y Bíceps")) {
            exercises = new String[]{
                    "Crunch 4x12",
                    "Martillos 4x12",
                    "Plancha isométrica 1 min",
                    "Extensiones con liga 4x20",
                    "Elevaciones de piernas 4x15",
                    "Bicicletas 4x20",
                    "Encogimientos invertidos 4x15",
                    "Hollow hold 4x12"
            };
        } else {
            exercises = new String[]{"No hay ejercicios disponibles"};
        }

        intent.putExtra("exercises", exercises);
        startActivity(intent);
    }

}