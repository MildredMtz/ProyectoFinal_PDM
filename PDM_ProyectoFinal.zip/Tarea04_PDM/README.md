# Tarea4
Programación de dispositivos moviles

## CERVANTES DUARTE JOSE FERNANDO 

## Paola Mildred Martinez Hidalgo


En esta tarea se implemento una base de datos para controlar el acceso a la aplicación , de manera que para poder acceder
se necesita registrarse .
Tambien se implementaron diversas Actividades para mejorar la utilidad de la apliacación
